# -*- coding: utf-8 -*-
"""Top-level package for Better Dict."""

__author__ = 'Erik Ingwersen'
__email__ = 'erik.ingwersen@br.ey.com'
__version__ = '0.0.1'


from .core import BetterDict
from .utils import *
