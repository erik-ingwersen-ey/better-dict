"""
Module defines helper functions for the `BetterDict` class.
"""
from __future__ import annotations

import pickle
from abc import abstractmethod
from pathlib import Path
from typing import Any, Dict, Hashable, Iterable, List, Tuple

from difflib import get_close_matches

import joblib
import numpy as np
import pandas as pd


__all__ = [
    "iterable_not_string",
    "same_length",
    "make_list",
    "flatten",
]


def iterable_not_string(value: object) -> bool:
    """Check if the value is iterable but not a string.

    Parameters
    ----------
    value : object
        Value to check.

    Returns
    -------
    bool
        True if the value is iterable but not a string, False otherwise.
    """
    return isinstance(value, Iterable) and not isinstance(value, str)


def same_length(keys: Any, values: Any) -> bool:
    """Check if the keys and values have the same length.

    Parameters
    ----------
    keys : Any
        Keys to check.
    values : Any
        Values to check.

    Returns
    -------
    bool
        True if the keys and values are iterables and have the same length,
        False otherwise.
    """
    if all(
        iterable_not_string(value) and hasattr(value, "__len__")
        for value in [keys, values]
    ):
        return len(keys) == len(values)
    return False


def make_list(value: Any) -> List[Any]:
    """Make a list from the value.

    Parameters
    ----------
    value : Any
        Value to make a list from.

    Returns
    -------
    List[Any]
        List with the value.
    """
    if value is None:
        return []
    return list(value) if iterable_not_string(value) else [value]


def flatten(iterable_obj: Iterable[Iterable[Any]]) -> Iterable[Any]:
    """Flatten the iterable object.

    Parameters
    ----------
    iterable_obj : Iterable[Iterable[Any]]
        Iterable object to flatten.

    Returns
    -------
    Iterable[Any]
        Flattened iterable object.
    """
    return (item for iterable in iterable_obj for item in make_list(iterable))
